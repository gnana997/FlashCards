# Mobile Flash Cards Project

This is my project for the final assessment project for Udacity's React Native course. 
It has been tested in Android platform

## TL;DR

To get started developing right away:

* install all project dependencies with `npm install`
* start the development server with `npm start`

This repository is my propject for Udacity's React Native course. Therefore, I most likely will not accept pull requests.

## Available Scripts

In the project directory, you can run:

### `expo start`

Runs the app in the development mode.<br />
Open [http://localhost:19000](http://localhost:19000) to view it in the browser.

The page will reload if you make edits.<br />
You will also see any lint errors in the console.

